# YoniPlayer

Diseño Centrado en el Usuario (Virtual) | 2022-C-2 | Juan Martínez López.

![image](https://user-images.githubusercontent.com/36041729/182527288-4efe6184-883f-4b0b-942a-aeedd33412b6.png)
